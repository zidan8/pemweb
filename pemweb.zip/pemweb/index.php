<!DOCTYPE HTML>
<!--
	Strata by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Profil ID</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->

	</head>
	<body id="top">

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="#" class="image avatar"><img src="images/avatar.jpg" alt="" /></a>
					<h4><a href="jadwal.php"> Jadwal kuliah</a></h4>
					<h4><a href="siswa.php"> Database Sekolah</a></h4>
					
				</div>
			</header>

		<!-- Main -->
			<div id="main">

				<!-- One -->
					<section id="one">
						<header class="major">
							<h2>i want to introduce my self.</h2>
						</header>
						<p>my name is Rizqi Zidanul Farhan, you can call me Zidan. i born in Brebes, 4st january 1998. and iam is a student in UIN Sunan Kalijaga Yogyakarta. my Skill is design graph and art. my hobby is watching video games. thanks</p>
					</section>

				<!-- Two -->
					<section id="two">
						<h2>Recent</h2>
						<div class="row">
							<article class="6u 12u$(xsmall) work-item">
								<a href="images/fulls/01.jpg" class="image fit thumb"><img src="images/thumbs/01.jpg" alt="" /></a>
								<h3> i like secuirity networking. because we can explore word in the smartphone or laptop</h3>
							</article>
							<article class="6u$ 12u$(xsmall) work-item">
								<a href="images/fulls/02.jpg" class="image fit thumb"><img src="images/thumbs/02.jpg" alt="" /></a>
								<h3>i like coding, inspiration after i watching processed made a video game<h3>
							</article>
							<article class="6u 12u$(xsmall) work-item">
								<a href="images/fulls/03.jpg" class="image fit thumb"><img src="images/thumbs/03.jpg" alt="" /></a>
								<h3>other my hobby, i like manipulate image to be perfect and profesional</h3>
							</article>
							<article class="6u$ 12u$(xsmall) work-item">
								<a href="images/fulls/04.jpg" class="image fit thumb"><img src="images/thumbs/04.jpg" alt="" /></a>
								<h3>music. who don't like music.</h3>
							</article>
							<article class="6u 12u$(xsmall) work-item">
								<a href="images/fulls/05.jpg" class="image fit thumb"><img src="images/thumbs/05.jpg" alt="" /></a>
								<h3>and traveling. you can build body health if you often jogging in under sun</h3>
							</article>
							<article class="6u$ 12u$(xsmall) work-item">
								<a href="images/fulls/06.jpg" class="image fit thumb"><img src="images/thumbs/06.jpg" alt="" /></a>
								<h3>Last, I like contemplating the future by developing the concept of early</h3>
							</article>
						</div>
					</section>
			</div>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					
					<ul class="actions">
							<li>
								<a href="login.php" class="button">Login</a>
							</li>
					</ul>
					<ul class="actions">
							<li>
								<a href="singup.php" class="button">Sing Up</a>
							</li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled</li><li>Login: <a href="admin.php"> Admin</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>