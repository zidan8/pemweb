<!DOCTYPE HTML>
<!--
	Strata by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>presensi</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->

	</head>
	<body id="top">

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="#" class="image avatar"><img src="images/avatar.jpg" alt="" /></a>
					<h3><a href="index.php"> Home</a></h3>
					<h3><a href="siswa.php"> Database Sekolah</a></h3>
				</div>
			</header>

		<!-- Main -->
			<div id="main">
				<!-- Two -->
					<section id="two">
						<div class="row">

							<table border="1">

							<h2>data_absensi_mobile</h2>
							<div class="row"></div>
			<tr>
				<td><center><b>id</b></center></td>
				<td><center><b>nip</b></center></td>
				<td><center><b>latitude</b></center></td>
				<td><center><b>longitude</b></center></td>
				<td><center><b>presensi_ke</b></center></td>
				<td><center><b>photo</b></center></td>
				<td><center><b>macaddress</b></center></td>
				<td><center><b>created_at</b></center></td>
			</tr>
			<tr>
				<td><center>11</center></td>
				<td>14650015</td>
				<td>-7.784395</td>
				<td>110.394295</td>
				<td>1</td>
				<td>photo<a href="http:\/\/orig12.deviantart.net\/bb23\/f\/2015\/227\/a\/5\/head_by_iqbaladinurmansyah-d95tk1c.gif"></td>
				<td>asus keren</td>
				<td>2016-10-30 07:00:00</td>
			</tr>
			<tr>
				<td><center>10</center></td>
				<td>14650015</td>
				<td>-7.784395</td>
				<td>110.394295</td>
				<td>1</td>
				<td>photo<a href="http:\/\/orig12.deviantart.net\/bb23\/f\/2015\/227\/a\/5\/head_by_iqbaladinurmansyah-d95tk1c.gif"></td>
				<td>asusususus</td>
				<td>2016-10-29 07:00:00</td>
			</tr>

			</table>
			</div>

			<div class="row">

							<table border="1">

							<h2>data_absensi_finger</h2>
							<div class="row"></div>
			<tr>
				<td><center><b>finger_id</b></center></td>
				<td><center><b>nip</b></center></td>
				<td><center><b>tag_date</b></center></td>
				<td><center><b>finger_ip</b></center></td>
			</tr>
			<tr>
				<td><center>10000</center></td>
				<td>14650015</td>
				<td>2016-10-29 17:00:00</td>
				<td>10.10.28.138</td>
			</tr>
			</table>
			</div>
			
			<h4>latest_update": "2017-03-24 11:17:46</h4>

		<!-- Footer -->
			<footer id="footer">
				
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>