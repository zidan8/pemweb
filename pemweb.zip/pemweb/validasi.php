<html>
	<head>
		<title>MTs Assalafiyah Sitanggal</title>
	</head>
	<body>
		<h1>Form Pendafaran Siswa Baru</h1>
		<script language="JavaScript">
			function validasi_input(form){
  			if (form.username.value == ""){
    			alert("Username masih kosong!");
    			form.username.focus();
    			return (false);
  			}
		
		</script>
	</body>
</html>